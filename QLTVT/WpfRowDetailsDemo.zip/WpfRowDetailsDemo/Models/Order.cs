namespace WpfRowDetailsDemo.Models
{
    public class Order
    {
        public string MasoDDH { get; set; } = "";
        public string NhaCC { get; set; } = "";
        public string MaKho { get; set; } = "";
        public int Manv { get; set; }
        public DateTime Ngay { get; set; }
    }
}
