using System.Collections.ObjectModel;

namespace WpfRowDetailsDemo.Models
{
    public class Employee
    {
        public int Manv { get; set; }
        public string Ho { get; set; } = "";
        public string Ten { get; set; } = "";
        public string DiaChi { get; set; } = "";
        public DateTime NgaySinh { get; set; }
        public int Luong { get; set; }
        public string MaCN { get; set; } = "";
        public int TrangThai { get; set; }

        public ObservableCollection<Order> Orders { get; } = new();
    }
}
