using System.Windows;

namespace WpfRowDetailsDemo
{
    public partial class App : Application { }
}
