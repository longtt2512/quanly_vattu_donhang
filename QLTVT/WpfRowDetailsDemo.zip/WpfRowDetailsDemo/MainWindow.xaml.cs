using System.Windows;
using WpfRowDetailsDemo.ViewModels;

namespace WpfRowDetailsDemo
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainWindowViewModel();
        }
    }
}
