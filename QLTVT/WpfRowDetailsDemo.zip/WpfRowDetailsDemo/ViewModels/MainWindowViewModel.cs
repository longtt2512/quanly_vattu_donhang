using System.Collections.ObjectModel;
using WpfRowDetailsDemo.Models;

namespace WpfRowDetailsDemo.ViewModels
{
    public class MainWindowViewModel
    {
        public ObservableCollection<Employee> Employees { get; } = new();

        public MainWindowViewModel()
        {
            // Demo seed data
            var e1 = new Employee { Manv = 1, Ho="Luong", Ten="Trang", DiaChi="Thu Duc", NgaySinh=new DateTime(2000,5,6), Luong=7000000, MaCN="CN1", TrangThai=0 };
            e1.Orders.Add(new Order { MasoDDH="MDDH01", NhaCC="CTY Điện máy xanh", MaKho="TD", Manv=1, Ngay=new DateTime(2017,9,15) });
            e1.Orders.Add(new Order { MasoDDH="MDDH02", NhaCC="CTY Panasonic", MaKho="TD", Manv=1, Ngay=new DateTime(2017,9,15) });

            var e2 = new Employee { Manv = 3, Ho="Tran", Ten="Thanh", DiaChi="Quan 10", NgaySinh=new DateTime(1994,7,4), Luong=5000000, MaCN="CN1", TrangThai=0 };
            var e3 = new Employee { Manv = 5, Ho="Ho", Ten="Thai", DiaChi="Binh Thanh", NgaySinh=new DateTime(2001,2,5), Luong=6000000, MaCN="CN1", TrangThai=0 };
            var e4 = new Employee { Manv = 7, Ho="Le", Ten="Thanh", DiaChi="Phu Nhuan", NgaySinh=new DateTime(1996,3,7), Luong=7000000, MaCN="CN1", TrangThai=1 };

            Employees.Add(e1);
            Employees.Add(e2);
            Employees.Add(e3);
            Employees.Add(e4);
        }
    }
}
